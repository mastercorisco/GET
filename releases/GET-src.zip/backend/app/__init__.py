"""GET backend application package."""

__version__ = "0.1.0"